package com.longcraft.client;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String MC_PACKAGE = "com.mojang.minecraftpe";
    private LinearLayout root;
    private TextView status;
    private int blue = Color.rgb(44, 145, 255);
    private int panel = Color.rgb(17, 31, 54);
    private int background = Color.rgb(7, 15, 29);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addSpace(LinearLayout box, int h) {
        View v = new View(this);
        box.addView(v, new LinearLayout.LayoutParams(1, h));
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18, 16, 18, 16);
        c.setBackground(shape(panel, 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, 14);
        root.addView(c, lp);
        return c;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(background);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 24, 20, 24);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("LONGCRAFT", 14, blue, true);
        brand.setLetterSpacing(0.18f);
        root.addView(brand);
        addSpace(root, 8);

        TextView title = text("Client Dashboard", 29, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text("Minecraft Bedrock · Profile 1.26.51", 14,
            Color.rgb(155, 174, 201), false);
        root.addView(subtitle);
        addSpace(root, 22);

        LinearLayout hero = card();
        TextView version = text("LONGCRAFT CLIENT", 12, blue, true);
        version.setLetterSpacing(0.12f);
        hero.addView(version);
        addSpace(hero, 8);
        hero.addView(text("Chơi game theo cách của bạn.", 20, Color.WHITE, true));
        addSpace(hero, 6);
        hero.addView(text("Launcher gọn nhẹ với giao diện Dark Blue.", 13,
            Color.rgb(173, 190, 214), false));
        addSpace(hero, 16);

        Button launch = new Button(this);
        launch.setText("MỞ MINECRAFT");
        launch.setTextColor(Color.WHITE);
        launch.setAllCaps(false);
        launch.setTextSize(15);
        launch.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        launch.setBackground(shape(blue, 18));
        hero.addView(launch, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 54));
        launch.setOnClickListener(v -> openMinecraft());

        LinearLayout game = card();
        game.addView(text("TRẠNG THÁI GAME", 12, blue, true));
        addSpace(game, 10);
        status = text("", 15, Color.WHITE, true);
        game.addView(status);
        addSpace(game, 5);
        game.addView(text("Gói Minecraft được kiểm tra bằng package Android.", 12,
            Color.rgb(155, 174, 201), false));
        updateStatus();

        LinearLayout modules = card();
        modules.addView(text("CLIENT MODULES", 12, blue, true));
        addSpace(modules, 12);
        addModule(modules, "HUD", "Bảng thông tin trong ứng dụng", "Chưa tích hợp vào game");
        addModule(modules, "ESP", "Đánh dấu đối tượng", "Cần API Bedrock phù hợp");
        addModule(modules, "X-RAY", "Hỗ trợ hiển thị quặng", "Chưa khả dụng trong launcher");
        addModule(modules, "CUSTOM UI", "Giao diện và cấu hình LongCraft", "Đang hoạt động");

        LinearLayout about = card();
        about.addView(text("THÔNG TIN", 12, blue, true));
        addSpace(about, 8);
        about.addView(text("LongCraft Client 1.0.0", 15, Color.WHITE, true));
        addSpace(about, 4);
        about.addView(text("Ứng dụng độc lập. Không sửa đổi dữ liệu Minecraft, không inject mã và không cam kết các module ESP/X-Ray hoạt động trong game.", 12,
            Color.rgb(155, 174, 201), false));
        addSpace(about, 12);
        TextView refresh = text("LÀM MỚI TRẠNG THÁI", 12, blue, true);
        refresh.setPadding(0, 8, 0, 8);
        about.addView(refresh);
        refresh.setOnClickListener(v -> updateStatus());
    }

    private void addModule(LinearLayout parent, String name, String description, String state) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, 8, 0, 8);
        row.addView(text(name, 15, Color.WHITE, true));
        row.addView(text(description, 12, Color.rgb(173, 190, 214), false));
        row.addView(text(state, 11, blue, true));
        parent.addView(row);
    }

    private boolean isMinecraftInstalled() {
        try {
            getPackageManager().getPackageInfo(MC_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(isMinecraftInstalled()
            ? "● Minecraft đã được cài đặt"
            : "● Chưa tìm thấy Minecraft Bedrock");
        status.setTextColor(isMinecraftInstalled()
            ? Color.rgb(104, 220, 160) : Color.rgb(255, 184, 92));
    }

    private void openMinecraft() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);
        if (launchIntent == null) {
            Toast.makeText(this, "Không tìm thấy Minecraft Bedrock. Hãy cài game trước.", Toast.LENGTH_LONG).show();
            updateStatus();
            return;
        }
        try {
            startActivity(launchIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Không thể mở Minecraft trên thiết bị này.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }
}
