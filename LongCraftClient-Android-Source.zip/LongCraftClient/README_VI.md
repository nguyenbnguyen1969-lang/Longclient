# LongCraft Client 1.0.0

Ứng dụng Android độc lập, giao diện Dark Blue, có nút kiểm tra và mở Minecraft Bedrock đã cài.

## Phạm vi bản 1.0.0
- Dashboard Dark Blue.
- Kiểm tra package `com.mojang.minecraftpe`.
- Mở Minecraft bằng Android launch intent.
- Hiển thị minh bạch trạng thái các module.
- Không inject, không sửa dữ liệu game, không tự nhận có ESP/X-Ray hoạt động.

## Build APK
Yêu cầu Android Studio mới, Android SDK Platform 35 và JDK 17.
1. Mở thư mục dự án bằng Android Studio.
2. Chờ Gradle Sync.
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Có thể dùng GitHub Actions: tải toàn bộ dự án lên một repository, mở tab Actions và chạy workflow **Build LongCraft APK**. Tải artifact `LongCraftClient-debug` sau khi workflow hoàn tất.

## Tương thích
- minSdk 23; targetSdk 35.
- Hồ sơ mục tiêu: Minecraft Bedrock 1.26.51. Ứng dụng hiện chỉ mở package Minecraft; chưa xác minh phiên bản game thực tế.
- Cần cài Minecraft Bedrock chính thức trên thiết bị.
- Không cần quyền overlay hoặc quyền truy cập tệp.
